function validateForm() {
	//

						alert(document.forms["RegistrationForm"]["Role"].value);

	var Name 				= document.forms["RegistrationForm"]["Name"].value;
	var EmailId 			= document.forms["RegistrationForm"]["EmailId"].value;
	var Password			= document.forms["RegistrationForm"]["Password"].value;
	var Confirmpassword 	= document.forms["RegistrationForm"]["Confirmpassword"].value;
	var ContactNumber 		= document.forms["RegistrationForm"]["ContactNumber"].value;
	var Address 			= document.forms["RegistrationForm"]["Location"].value;
	var Role 				= document.forms["RegistrationForm"]["Role"].value;
	var SpecialChar 		= /^(?=.*\d)(?=.*[a-z])(?=.*[A-Z])(?=.*[^a-zA-Z0-9])(?!.*\s).{8}$/;
	var phoneno 			= /^\d{10}$/;
	var fields 				= [ "Email", "Name", "Password", "ContactNumber", "Location",
								"Confirmpassword", "Role" ]
	var i;
	var fieldname;

	for (i = 0; i < fields.length; i++) {
		fieldname = fields[i];
		if (document.forms["RegistrationForm"][fieldname].value === "") {
			alert(fieldname + " can not be empty");
			return false;
		}
	}

		if (!(document.forms["RegistrationForm"]["Password"].value
			.match(SpecialChar))) {

		alert("Password Not Follow the Given pattern ");
		return false;
	}

		if (!(document.forms["RegistrationForm"]["ContactNumber"].value
			.match(phoneno))) {

		alert("Mobile no should have 10 digit");
		return false;
	}
		if (isNaN(document.forms["RegistrationForm"]["ContactNumber"].value)) {
		alert("MobNumber Should be Number");
		return false;
	}

		if (Password != Confirmpassword) {
		alert(" Password Mis-Match");
		document.forms["RegistrationForm"]["Confirmpassword"].focus();
		return false;
	}
	
		if (Password == EmailId) {
		alert(" Email id and password should not be match");
		document.forms["RegistrationForm"]["Password"].focus();
		return false;
	}

}