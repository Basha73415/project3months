package com.hcl.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.apache.log4j.Logger;
import com.hcl.bean.FinalOrderBean;
import com.hcl.bean.MenuBean;
import com.hcl.bean.OrderBean;
import com.hcl.bean.RestaurantBean;
import com.hcl.bean.UserRegisterBean;

public class UserData {

	final static Logger logger = Logger.getLogger(UserData.class);

	DatabaseDAO data = null;
	Connection connection = null;

	private static final String GET_MENU_VEG = "SELECT * FROM MENU WHERE VEGNONVEG='Veg' AND RESTAURANTCODE=(SELECT RESTAURANTCODE FROM RESTAURANT WHERE RESTAURANTNAME=?)";

	private static final String GET_MENU_NONVEG = "SELECT * FROM MENU WHERE VEGNONVEG='NonVeg' AND RESTAURANTCODE=(SELECT RESTAURANTCODE FROM RESTAURANT WHERE RESTAURANTNAME=?)";

	private static final String GET_ITEM_HISTORY = "SELECT  B.ITEMNAME,A.UNITPRICE,A.ITEMQTY,A.AMOUNT FROM ORDERITEM A,MENU B WHERE ORDERNUMBER = ? AND A.ITEMCODE=B.ITEMCODE AND A.RESTAURANTCODE = B.RESTAURANTCODE";

	private static final String GET_ORDER_HISTORY = "SELECT * FROM ORDERHEADER WHERE CONTACTNUMBER=? ";

	private static final String INSERT_ORDERITEM = "INSERT INTO ORDERITEM VALUES(?,?,?,?,?,?)";

	private static final String GET_RESTRO_CODE = "SELECT RESTAURANTCODE FROM RESTAURANT  WHERE RESTAURANTNAME=?";

	private static final String UPDATE_ORDER_NUMBER = "UPDATE CONTROLTABLE SET CONTROLVALUE=CONTROLVALUE+1 WHERE CONTROLKEY='ORDERNUMBER'";

	private static final String GET_ORDER_NUMBER = "SELECT CONTROLVALUE FROM CONTROLTABLE WHERE CONTROLKEY='ORDERNUMBER'";

	private static final String INSERT_FINALORDER = "INSERT INTO ORDERHEADER VALUES(?,?,?,?,?,?,?)";

	private static final String REMOVE_TEMP_ORDER = "DELETE FROM ORDERTEMP WHERE EMAILID=?";

	private static final String GET_ORDERDATA = "SELECT A.NAME,A.CONTACTNUMBER ,A.LOCATION ,B.ORDERDATE,B.ORDERNUMBER,B.ORDERAMOUNT FROM REGISTRATION A, ORDERTEMP B WHERE A.EMAILID = B.EMAILID";

	private static final String INSERT_ORDER = "INSERT INTO ORDERTEMP(ORDERAMOUNT,ORDERDATE,EMAILID) VALUES(?,?,?)";

	private static final String DELETE_RECORD = "DELETE FROM MENUITEM WHERE ITEMCODE=?";

	private static final String INSERT_USERS_SQL = "INSERT INTO Registration"
			+ "  (EmailId, Name, Password,ContactNumber,Location,Role) VALUES " + " (?,?,?,?,?,?);";

	private static final String SELECT_USER_BY_EMAIL = "SELECT EmailId, Name, Password,ContactNumber,Location,Role from Registration where EmailId =? and Password=?;";

	private static final String SELECT_ALL_RESTAURANTNAME = "select restaurantname,contactnumber from restaurant limit ?,?";

	private static final String SELECT_ITEM_DATA = "SELECT ITEMCODE,ITEMNAME,ITEMPRICE,VegNonVeg,CATEGORY FROM MENU WHERE RESTAURANTCODE=(SELECT RESTAURANTCODE FROM RESTAURANT WHERE RESTAURANTNAME=?)";

	private static final String ADD_ITEM = "INSERT INTO MenuItem"
			+ "  (ItemCode, ItemName, ItemPrice,ItemQty,ItemAmount,EmailId) VALUES " + " (?,?,?,?,?,?);";

	private static final String GET_ITEM = "SELECT * FROM MENUITEM";

	private static final String DELETE_ITEM = "DELETE FROM MENUITEM WHERE EMAILID=?";

	private static final String UPDATE_ITEM = "UPDATE MENUITEM SET ITEMNAME =?,ITEMPRICE = ?,ITEMQTY=?,ITEMAMOUNT=?  WHERE ITEMCODE=?";

	private static final String GET_CONTACT_NUMBER = "SELECT CONTACTNUMBER FROM REGISTRATION WHERE EMAILID=? ";

	private static final String SELECT_NEW_ITEM_DATA = "SELECT * FROM MENUITEM WHERE ITEMCODE=?";

	public UserData() {
		data = new DatabaseDAOImpl();
		connection = data.getConnection();
	}

	public void insertUserData(UserRegisterBean userBean) {

		if (connection != null) {
			logger.info("--------------Connection created--------------");
			PreparedStatement preparedStatement;
			try {
				preparedStatement = connection.prepareStatement(INSERT_USERS_SQL);
				preparedStatement.setString(1, userBean.getEmailId());
				preparedStatement.setString(2, userBean.getName());
				preparedStatement.setString(3, userBean.getPassword());
				preparedStatement.setString(4, userBean.getContactNumber());
				preparedStatement.setString(5, userBean.getLocation());
				preparedStatement.setString(6, userBean.getRole());
				logger.info("Inside insertUserData " + preparedStatement);
				preparedStatement.executeUpdate();
			} catch (SQLException e) {
				logger.error(e);
			}

		}

	}

	public List<RestaurantBean> getRestaurantData(int pageId, int total) {
		int id = pageId - 1;

		PreparedStatement preparedStatement;

		List<RestaurantBean> restaurantList = new ArrayList<>();
		try {
			preparedStatement = connection.prepareStatement(SELECT_ALL_RESTAURANTNAME);
			preparedStatement.setInt(1, id);
			preparedStatement.setInt(2, total);
			ResultSet rs = preparedStatement.executeQuery();
			logger.info("Inside getRestaurantData " + rs);
			while (rs.next()) {
				restaurantList.add(new RestaurantBean(rs.getString(1), rs.getString(2)));

			}
			return restaurantList;

		} catch (SQLException e) {
			logger.error(e);
		}

		return null;

	}

	public int getRestroCode(String restaurantName) throws SQLException {

		int restaurantCode = 0;
		PreparedStatement pre = connection.prepareStatement(GET_RESTRO_CODE);
		pre.setString(1, restaurantName);
		ResultSet rs = pre.executeQuery();
		rs.next();
		restaurantCode = rs.getInt(1);
		return restaurantCode;
	}

	public List<MenuBean> getItemData(String restaurantName) {
		List<MenuBean> menu = new ArrayList<>();
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(SELECT_ITEM_DATA);
			preparedStatement.setString(1, restaurantName);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				menu.add(new MenuBean(rs.getInt(1), rs.getString(2), rs.getFloat(3), rs.getString(4), rs.getString(5)));
			}

		} catch (SQLException e) {
			logger.error(e);
		}
		return menu;

	}

	public Boolean validateLogIn(String emailId, String Password) {
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(SELECT_USER_BY_EMAIL);
			preparedStatement.setString(1, emailId);
			preparedStatement.setString(2, Password);

			logger.info("Inside validateLogin " + preparedStatement);
			ResultSet rs = preparedStatement.executeQuery();
			if (rs.next()) {
				return true;
			}
		} catch (SQLException e) {
			e.printStackTrace();
		}
		return false;
	}

	public void addMenuItem(List<OrderBean> orderList, String emailId) throws SQLException {

		for (OrderBean order : orderList) {
			PreparedStatement preparedstatement = connection.prepareStatement(ADD_ITEM);
			preparedstatement.setInt(1, order.getItemCode());
			preparedstatement.setString(2, order.getItemName());
			preparedstatement.setFloat(3, order.getItemPrice());
			preparedstatement.setInt(4, order.getQuantity());
			preparedstatement.setFloat(5, order.getItemAmount());
			preparedstatement.setString(6, emailId);

			logger.info("Inside addMenuItem " + preparedstatement);
			preparedstatement.executeUpdate();
		}

	}

	public List<OrderBean> getMenuItem() throws SQLException {

		List<OrderBean> list = new ArrayList<OrderBean>();

		PreparedStatement preparedstatement = connection.prepareStatement(GET_ITEM);
		logger.info("Inside getMenuItem " + preparedstatement);
		ResultSet set = preparedstatement.executeQuery();
		logger.info(set);
		while (set.next()) {
			list.add(new OrderBean(set.getInt(1), set.getString(2), set.getFloat(3), set.getInt(4), set.getFloat(5)));
		}
		return list;
	}

	public Boolean deleteMenuItem(String emailId) throws SQLException {
		PreparedStatement preparedstatement = connection.prepareStatement(DELETE_ITEM);
		preparedstatement.setString(1, emailId);
		logger.info("Delete Query ------------------" + preparedstatement);
		int i = preparedstatement.executeUpdate();
		if (i > 0) {
			return true;
		}
		return false;
	}

	public void deleteRecord(int itemCode) {

		try {
			PreparedStatement preparedstatement = connection.prepareStatement(DELETE_RECORD);
			preparedstatement.setInt(1, itemCode);
			preparedstatement.executeUpdate();
		} catch (SQLException e) {
			logger.error(e);
		}

	}

	public boolean readFromDatabase(String EmailId, String Password) throws SQLException {

		PreparedStatement preparedstatement = connection.prepareStatement(SELECT_NEW_ITEM_DATA);
		preparedstatement.setString(1, EmailId);
		preparedstatement.setString(2, Password);
		logger.info("Inside readFromDatabase" + preparedstatement);
		ResultSet rs = preparedstatement.executeQuery();
		if (rs.next()) {
			return true;
		}
		return false;

	}

	public boolean updateRecord(OrderBean orderBean) throws SQLException

	{
		logger.info("Inside updateRecord ");
		PreparedStatement preparedstatement = connection.prepareStatement(UPDATE_ITEM);
		preparedstatement.setString(1, orderBean.getItemName());
		preparedstatement.setFloat(2, orderBean.getItemPrice());
		preparedstatement.setInt(3, orderBean.getQuantity());
		preparedstatement.setFloat(4, orderBean.getItemAmount());
		preparedstatement.setInt(5, orderBean.getItemCode());
		logger.info("Update Query " + preparedstatement);
		int result = preparedstatement.executeUpdate();
		logger.info("Result after updating " + result);
		if (result > 0) {
			return true;
		}
		return false;
	}

	public int getOrderNumber() throws SQLException {
		int orderNumber = 0;
		ResultSet rs = null;
		PreparedStatement preparedStatement = connection.prepareStatement(UPDATE_ORDER_NUMBER);
		PreparedStatement preparedStatement2 = connection.prepareStatement(GET_ORDER_NUMBER);
		int i = preparedStatement.executeUpdate();
		logger.info("After update" + i);
		if (i > 0)
			rs = preparedStatement2.executeQuery();
		rs.next();
		orderNumber = rs.getInt(1);
		return orderNumber;
	}

	public OrderBean getItemData(int itemCode) throws SQLException {

		OrderBean orderBean = new OrderBean();
		PreparedStatement preparedStatement = connection.prepareStatement(SELECT_NEW_ITEM_DATA);
		preparedStatement.setInt(1, itemCode);
		ResultSet rs = preparedStatement.executeQuery();
		while (rs.next()) {
			orderBean.setItemCode(rs.getInt(1));
			orderBean.setItemName(rs.getString(2));
			orderBean.setItemPrice(rs.getFloat(3));
			orderBean.setQuantity(rs.getInt(4));
			orderBean.setItemAmount(rs.getFloat(5));
		}
		logger.info("To find Exception" + orderBean);
		return orderBean;
	}

	public FinalOrderBean getOrderData() throws SQLException {
		FinalOrderBean order = null;
		PreparedStatement preparedStatement = connection.prepareStatement(GET_ORDERDATA);
		ResultSet rs = preparedStatement.executeQuery();
		logger.info("Resultset size of getOrderData" + rs.getFetchSize());
		while (rs.next()) {
			order = new FinalOrderBean(rs.getString(1), rs.getString(2), rs.getString(3), rs.getTimestamp(4),
					rs.getInt(5), rs.getFloat(6));
		}
		logger.info("Getting final orderdetails" + order);
		return order;
	}

	public boolean insertOrder(String emailId, float orderAmount) throws SQLException {
		Date date = new Date();
		long time = date.getTime();
		logger.info("Time in Milliseconds: " + time);
		Timestamp ts = new Timestamp(time);
		logger.info("Current Time Stamp: " + ts);
		PreparedStatement preparedStatement = connection.prepareStatement(INSERT_ORDER);
		preparedStatement.setFloat(1, orderAmount);
		preparedStatement.setTimestamp(2, ts);
		preparedStatement.setString(3, emailId);
		int insertResult = preparedStatement.executeUpdate();
		logger.info("Result after insertingOrder " + insertResult);
		if (insertResult > 0) {
			return true;
		}
		return false;
	}

	/*
	 * public List<MenuBean> getItemList(int restaurentCode, int pageNo, int
	 * recordPerPage) throws SQLException, ClassNotFoundException { List<MenuBean>
	 * menuBean = new ArrayList<MenuBean>(); PreparedStatement statement =
	 * connection.prepareStatement(PAGINATION); statement.setInt(1, restaurentCode);
	 * statement.setInt(2, pageNo); statement.setInt(3, recordPerPage);
	 * 
	 * ResultSet result = statement.executeQuery();
	 * 
	 * while (result.next()) { menuBean.add(new MenuBean(result.getInt(2),
	 * result.getString(3), result.getFloat(4), result.getString(5),
	 * result.getString(6)));
	 * 
	 * } System.out.println("List data " + menuBean);
	 * 
	 * return menuBean; }
	 */

	public boolean insertFinalData(FinalOrderBean finalOrder, String modeOfPayment, String cardNumber, String emailId)
			throws SQLException {

		PreparedStatement preparedStatement = connection.prepareStatement(INSERT_FINALORDER);
		preparedStatement.setInt(1, finalOrder.getOrderNumber());
		preparedStatement.setTimestamp(2, finalOrder.getOrderDate());
		preparedStatement.setString(3, finalOrder.getContactNumber());
		preparedStatement.setString(4, finalOrder.getLocation());
		preparedStatement.setFloat(5, finalOrder.getOrderAmount());
		preparedStatement.setString(6, modeOfPayment);
		preparedStatement.setString(7, cardNumber);
		int result = preparedStatement.executeUpdate();
		if (result > 0) {
			PreparedStatement ps = connection.prepareStatement(REMOVE_TEMP_ORDER);
			ps.setString(1, emailId);
			int i = ps.executeUpdate();
			logger.info("Inserted Successfully");
			if (i > 0) {
				logger.info("=================================Deleted Row====================================" + i);
			}
			return true;
		} else {
			logger.info("Not inserted successfully in insertFinalData");
			return false;

		}

	}

	public void insertMenu(int orderNumber, List<OrderBean> list, int restaurantCode) throws SQLException {

		PreparedStatement preparedStatement = connection.prepareStatement(INSERT_ORDERITEM);
		for (OrderBean orderBean : list) {
			preparedStatement.setInt(1, orderNumber);
			preparedStatement.setInt(2, orderBean.getItemCode());
			preparedStatement.setInt(3, orderBean.getQuantity());
			preparedStatement.setFloat(4, orderBean.getItemPrice());
			preparedStatement.setFloat(5, orderBean.getItemAmount());
			preparedStatement.setInt(6, restaurantCode);
			logger.info("OrderBean List ::" + list);
			preparedStatement.executeUpdate();
		}

	}

	public List<OrderBean> getItemHistory(int orderNumber) throws SQLException {
		List<OrderBean> list = new ArrayList<>();

		PreparedStatement preparedStatement = connection.prepareStatement(GET_ITEM_HISTORY);
		preparedStatement.setInt(1, orderNumber);
		logger.info("Prepared Item History" + preparedStatement);
		ResultSet rs = preparedStatement.executeQuery();
		while (rs.next()) {
			list.add(new OrderBean(rs.getInt(3), rs.getString(1), rs.getFloat(2), rs.getFloat(4)));
		}
		logger.info("Item History List::" + list);
		return list;

	}

	public String getContactNumber(String EmailId) throws SQLException {

		PreparedStatement preparedStatement = connection.prepareStatement(GET_CONTACT_NUMBER);
		preparedStatement.setString(1, EmailId);
		ResultSet rs = preparedStatement.executeQuery();
		rs.next();
		String ContactNumber = rs.getString(1);
		logger.info("CONTACTNUMBER " + ContactNumber);
		return ContactNumber;

	}

	public List<FinalOrderBean> getOrderHistory(String contactNumber) throws SQLException {

		List<FinalOrderBean> list = new ArrayList<>();
		PreparedStatement preparedStatement = connection.prepareStatement(GET_ORDER_HISTORY);
		preparedStatement.setString(1, contactNumber);
		ResultSet rs = preparedStatement.executeQuery();
		while (rs.next()) {
			list.add(new FinalOrderBean(rs.getString(3), rs.getString(4), rs.getTimestamp(2), rs.getInt(1),
					rs.getFloat(5)));
		}
		return list;
	}

	public List<MenuBean> getMenuVeg(String restaurantName) {
		List<MenuBean> menu = new ArrayList<>();
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(GET_MENU_VEG);
			preparedStatement.setString(1, restaurantName);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				menu.add(new MenuBean(rs.getInt(2), rs.getString(3), rs.getFloat(4), rs.getString(5), rs.getString(6)));
			}
		} catch (SQLException e) {
			logger.error(e);
		}
		return menu;

	}

	public List<MenuBean> getMenuNonVeg(String restaurantName) {
		List<MenuBean> menu = new ArrayList<>();
		try {
			PreparedStatement preparedStatement = connection.prepareStatement(GET_MENU_NONVEG);
			preparedStatement.setString(1, restaurantName);
			ResultSet rs = preparedStatement.executeQuery();
			while (rs.next()) {
				menu.add(new MenuBean(rs.getInt(2), rs.getString(3), rs.getFloat(4), rs.getString(5), rs.getString(6)));
			}

		} catch (SQLException e) {
			logger.error(e);
		}
		return menu;

	}

}
