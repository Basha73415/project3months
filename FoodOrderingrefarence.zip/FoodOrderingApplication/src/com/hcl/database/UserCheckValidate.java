package com.hcl.database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import org.apache.log4j.Logger;

public class UserCheckValidate {
	DatabaseDAO data = null;
	Connection con = null;
	private static final String SELECT_USER_BY_EMAIL = "select * from Registration where EmailId =?;";
	final static Logger logger = Logger.getLogger(UserCheckValidate.class);

	public UserCheckValidate() {
		data = new DatabaseDAOImpl();
		con = data.getConnection();
	}

	public boolean isEmailExists(String Email) {
		logger.info("inside email exists method");
		try {
			PreparedStatement preparedStatement = con.prepareStatement(SELECT_USER_BY_EMAIL);
			preparedStatement.setString(1, Email);

			System.out.println(preparedStatement);
			ResultSet rs = preparedStatement.executeQuery();
			if (rs.next()) {
				return false;
			}
		} catch (SQLException e) {
			logger.error(e);
		}
		return true;

	}

}
