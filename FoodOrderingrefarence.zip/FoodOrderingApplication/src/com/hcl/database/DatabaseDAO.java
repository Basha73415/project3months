package com.hcl.database;

import java.sql.Connection;

public interface DatabaseDAO {
	public Connection getConnection();
}
