package com.hcl.database;

import java.sql.Connection;
import java.sql.DriverManager;

import org.apache.log4j.Logger;

public class DatabaseDAOImpl implements DatabaseDAO {
	final static String DBURL = "jdbc:mysql://localhost:3306/FoodApp";
	final static Logger logger = Logger.getLogger(DatabaseDAOImpl.class);
	final static String USERNAME = "root";
	final static String PASSWORD = "root";
	Connection con = null;

	@Override
	public Connection getConnection() {

		try {
			Class.forName("com.mysql.jdbc.Driver");
			con = DriverManager.getConnection(DBURL, USERNAME, PASSWORD);
			if (con != null) {
				logger.info("Connection created");
				return con;

			}
		} catch (Exception e) {
			logger.error(e);
		}
		return null;

	}

}
