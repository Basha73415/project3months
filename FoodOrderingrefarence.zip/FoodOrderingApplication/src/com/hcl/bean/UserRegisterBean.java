package com.hcl.bean;

/**
 * User.java This is a model class represents a User entity
 * 
 * @author Aditya Awatare
 *
 */
public class UserRegisterBean {
	private String EmailId;
	private String Name;
	private String Password;
	private String ContactNumber;
	private String Location;
	private String Role;

	public UserRegisterBean() {
	}

	public UserRegisterBean(String emailId, String name, String password, String contactNumber, String location,
			String role) {
		super();
		EmailId = emailId;
		Name = name;
		Password = password;
		ContactNumber = contactNumber;
		Location = location;
		Role = role;
	}

	public String getEmailId() {
		return EmailId;
	}

	public void setEmailId(String emailId) {
		EmailId = emailId;
	}

	public String getName() {
		return Name;
	}

	public void setName(String name) {
		Name = name;
	}

	public String getPassword() {
		return Password;
	}

	public void setPassword(String password) {
		Password = password;
	}

	public String getContactNumber() {
		return ContactNumber;
	}

	public void setContactNumber(String contactNumber) {
		ContactNumber = contactNumber;
	}

	public String getLocation() {
		return Location;
	}

	public void setLocation(String location) {
		Location = location;
	}

	public String getRole() {
		return Role;
	}

	public void setRole(String role) {
		Role = role;
	}

}
