package com.hcl.bean;

import java.sql.Timestamp;

public class FinalOrderBean {

	private String name;
	private String contactNumber;
	private String location;
	private Timestamp orderDate;
	private int orderNumber;
	private float orderAmount;

	public FinalOrderBean() {

	}

	public FinalOrderBean(String name, String contactNumber, String location, Timestamp orderDate, int orderNumber,
			float orderAmount) {
		super();
		this.name = name;
		this.contactNumber = contactNumber;
		this.location = location;
		this.orderDate = orderDate;
		this.orderNumber = orderNumber;
		this.orderAmount = orderAmount;
	}

	public FinalOrderBean(String contactNumber, String location, Timestamp orderDate, int orderNumber,
			float orderAmount) {
		super();
		this.contactNumber = contactNumber;
		this.location = location;
		this.orderDate = orderDate;
		this.orderNumber = orderNumber;
		this.orderAmount = orderAmount;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public Timestamp getOrderDate() {
		return orderDate;
	}

	public void setOrderDate(Timestamp orderDate) {
		this.orderDate = orderDate;
	}

	public int getOrderNumber() {
		return orderNumber;
	}

	public void setOrderNumber(int orderNumber) {
		this.orderNumber = orderNumber;
	}

	public float getOrderAmount() {
		return orderAmount;
	}

	public void setOrderAmount(float orderAmount) {
		this.orderAmount = orderAmount;
	}

	@Override
	public String toString() {
		return "FinalOrderBean [name=" + name + ", contactNumber=" + contactNumber + ", location=" + location
				+ ", orderDate=" + orderDate + ", orderNumber=" + orderNumber + ", orderAmount=" + orderAmount + "]";
	}

}
