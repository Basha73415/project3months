package com.hcl.bean;

public class OrderBean {

	private int itemCode;
	private int quantity;
	private String itemName;
	private float itemPrice;
	private float itemAmount;
	private float totalAmount;
	private String emailId;

	public OrderBean() {
		super();
	}

	public OrderBean(int itemCode, String itemName, float itemPrice, int quantity, float itemAmount) {
		super();
		this.itemCode = itemCode;
		this.quantity = quantity;
		this.itemName = itemName;
		this.itemPrice = itemPrice;
		this.itemAmount = itemAmount;
	}

	public OrderBean(int quantity, String itemName, float itemPrice, float itemAmount) {
		super();
		this.quantity = quantity;
		this.itemName = itemName;
		this.itemPrice = itemPrice;
		this.itemAmount = itemAmount;
	}

	public float getTotalAmount() {
		return totalAmount;
	}

	public void setTotalAmount(float totalAmount) {
		this.totalAmount = totalAmount;
	}

	public float getItemAmount() {
		return itemAmount;
	}

	public void setItemAmount(float itemAmount) {
		this.itemAmount = itemAmount;
	}

	public int getItemCode() {
		return itemCode;
	}

	public float getItemPrice() {
		return itemPrice;
	}

	public void setItemPrice(float itemPrice) {
		this.itemPrice = itemPrice;
	}

	public void setItemCode(int itemCode) {
		this.itemCode = itemCode;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	@Override
	public String toString() {
		return "OrderBean [itemCode=" + itemCode + ", quantity=" + quantity + ", itemName=" + itemName + ", itemPrice="
				+ itemPrice + ", itemAmount=" + itemAmount + ", totalAmount=" + totalAmount + ", emailId=" + emailId
				+ "]";
	}

}
