package com.hcl.bean;

public class RestaurantBean {
	private int restaurantCode;
	private String restaurantName;
	private String location;
	private String contactNumber;

	public RestaurantBean() {
		super();
	}

	public RestaurantBean(String restaurantName, String contactNumber) {
		super();
		this.restaurantName = restaurantName;
		this.contactNumber = contactNumber;
	}

	public int getRestaurantCode() {
		return restaurantCode;
	}

	public void setRestaurantCode(int restaurantCode) {
		this.restaurantCode = restaurantCode;
	}

	public String getRestaurantName() {
		return restaurantName;
	}

	public void setRestaurantName(String restaurantName) {
		this.restaurantName = restaurantName;
	}

	public String getLocation() {
		return location;
	}

	public void setLocation(String location) {
		this.location = location;
	}

	public String getContactNumber() {
		return contactNumber;
	}

	public void setContactNumber(String contactNumber) {
		this.contactNumber = contactNumber;
	}

}
