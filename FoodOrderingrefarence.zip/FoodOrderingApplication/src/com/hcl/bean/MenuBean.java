package com.hcl.bean;

public class MenuBean {

	private int restaurantCode;
	private int itemCode;
	private String itemName;
	private float itemPrice;
	private String vegNonVeg;
	private String category;

	public MenuBean(int itemCode, String itemName, float itemPrice, String vegNonVeg, String category) {
		super();
		this.itemCode = itemCode;
		this.itemName = itemName;
		this.itemPrice = itemPrice;
		this.vegNonVeg = vegNonVeg;
		this.category = category;
	}

	public int getRestaurantCode() {
		return restaurantCode;
	}

	public void setRestaurantCode(int restaurantCode) {
		this.restaurantCode = restaurantCode;
	}

	public int getItemCode() {
		return itemCode;
	}

	public void setItemCode(int itemCode) {
		this.itemCode = itemCode;
	}

	public String getItemName() {
		return itemName;
	}

	public void setItemName(String itemName) {
		this.itemName = itemName;
	}

	public float getItemPrice() {
		return itemPrice;
	}

	public void setItemPrice(float itemPrice) {
		this.itemPrice = itemPrice;
	}

	public String getVegNonVeg() {
		return vegNonVeg;
	}

	public void setVegNonVeg(String vegNonVeg) {
		this.vegNonVeg = vegNonVeg;
	}

	public String getCategory() {
		return category;
	}

	public void setCategory(String category) {
		this.category = category;
	}

}
