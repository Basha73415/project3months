package com.hcl.controller;

import java.io.IOException;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.hcl.bean.UserRegisterBean;
import com.hcl.database.UserCheckValidate;
import com.hcl.database.UserData;

/**
 * Servlet implementation class UserRegisterServlet
 */
@WebServlet("/userRegistration")
public class UserRegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	final static Logger logger = Logger.getLogger(UserRegisterServlet.class);

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UserRegisterServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see Servlet#init(ServletConfig)
	 */
	public void init(ServletConfig config) throws ServletException {
		// TODO Auto-generated method stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// doGet(request, response);

		boolean isValidate = false;
		UserCheckValidate userValidate = new UserCheckValidate();
		String EmailId = request.getParameter("EmailId");
		String Name = request.getParameter("Name");
		String Password = request.getParameter("Password");
		String ContactNumber = request.getParameter("ContactNumber");
		String Location = request.getParameter("Location");
		String Role = request.getParameter("Role");

		UserRegisterBean userBean = new UserRegisterBean();
		userBean.setEmailId(EmailId);
		userBean.setName(Name);
		userBean.setPassword(Password);
		userBean.setContactNumber(ContactNumber);
		userBean.setLocation(Location);
		userBean.setRole(Role);

		isValidate = userValidate.isEmailExists(EmailId);
		logger.info(isValidate);
		if (isValidate) {
			UserData userData = new UserData();
			userData.insertUserData(userBean);
			response.sendRedirect("index.html");
		} else {
			response.sendRedirect("RegisterError.html");
		}

	}

}