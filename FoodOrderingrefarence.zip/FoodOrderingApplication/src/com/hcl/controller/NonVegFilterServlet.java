package com.hcl.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.hcl.bean.MenuBean;
import com.hcl.bean.OrderBean;
import com.hcl.database.UserData;

/**
 * Servlet implementation class NonVegFilterServlet
 */
@WebServlet("/NonVegFilterServlet")
public class NonVegFilterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	final static Logger logger = Logger.getLogger(NonVegFilterServlet.class);

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public NonVegFilterServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		logger.info("INSIDE POST==========================================");
		float totalAmount = 0;

		List<OrderBean> orderList = new ArrayList<OrderBean>();
		HttpSession session = request.getSession();
		String emailId = (String) session.getAttribute("EmailId");
		UserData base = new UserData();
		try {
			List<MenuBean> list = base.getMenuNonVeg(request.getParameter("restaurantName"));
			logger.info("LIST ====" + list.size());

			for (MenuBean menuBean : list) {

				OrderBean order = new OrderBean();

				int itemCode = Integer.parseInt(request.getParameter("ItemCode" + menuBean.getItemCode()));
				int Quantity = Integer.parseInt(request.getParameter("quantity" + menuBean.getItemCode()));
				float itemPrice = Float.parseFloat(request.getParameter("ItemPrice" + menuBean.getItemPrice()));

				float itemAmount = 0.0f;

				String itemName = request.getParameter("ItemName" + menuBean.getItemName());

				if (Quantity > 0) {

					itemAmount = itemPrice * Quantity;
					totalAmount += itemAmount;

					order.setItemCode(itemCode);
					order.setQuantity(Quantity);
					order.setItemPrice(itemPrice);
					order.setItemName(itemName);
					order.setItemAmount(itemAmount);

					orderList.add(order);

				}
			}
			if (orderList.size() > 0) {

				UserData user = new UserData();

				user.addMenuItem(orderList, emailId);

				response.sendRedirect("Cart.jsp?restaurantName=" + request.getParameter("restaurantName")
						+ "&orderAmount=" + totalAmount);
			}

		} catch (SQLException e) {
			logger.error(e);
		}
	}
}
