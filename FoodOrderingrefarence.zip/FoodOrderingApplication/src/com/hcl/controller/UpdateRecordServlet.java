package com.hcl.controller;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;

import com.hcl.bean.OrderBean;
import com.hcl.database.UserData;

/**
 * Servlet implementation class UpdateRecord
 */
@WebServlet("/UpdateRecord")
public class UpdateRecordServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	final static Logger logger = Logger.getLogger(UpdateRecordServlet.class);

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public UpdateRecordServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);

		String RestaurantName = request.getParameter("restaurantName");

		int itemCode = Integer.parseInt(request.getParameter("ItemCode"));
		String itemName = request.getParameter("ItemName");

		float itemPrice = Float.parseFloat(request.getParameter("ItemPrice"));
		int itemQuantity = Integer.parseInt(request.getParameter("ItemQuantity"));

		float oldItemAmount = Float.parseFloat(request.getParameter("itemAmount"));

		float newItemAmount = Float.parseFloat(request.getParameter("ItemAmount"));
		logger.info("ItemAmount==========" + oldItemAmount);
		float orderTemp = Float.parseFloat(request.getParameter("orderAmount"));

		logger.info("Existence OrderAmount==========" + orderTemp);

		float order = orderTemp - oldItemAmount;
		logger.info("Operation=======" + (orderTemp - oldItemAmount));
		logger.info("after reducing========" + order);
		OrderBean orderBean = new OrderBean(itemCode, itemName, itemPrice, itemQuantity, newItemAmount);
		UserData userDataBase = new UserData();
		try {
			boolean result = userDataBase.updateRecord(orderBean);
			OrderBean orderBean2 = userDataBase.getItemData(itemCode);
			float itemAmount2 = orderBean2.getItemAmount();
			logger.info("Updated ItemAmount" + itemAmount2);
			float orderAmount = order + itemAmount2;
			logger.info("Updated Order Amount" + orderAmount);
			if (result) {
				response.sendRedirect("Cart.jsp?orderAmount=" + orderAmount + "&RestaurantName=" + RestaurantName);
			} else {
				response.sendRedirect("cartError.jsp");
			}
		} catch (SQLException e) {
			logger.error(e);
		}

	}

}