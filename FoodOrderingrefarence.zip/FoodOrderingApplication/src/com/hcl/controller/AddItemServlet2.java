package com.hcl.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.log4j.Logger;

import com.hcl.bean.MenuBean;
import com.hcl.bean.OrderBean;
import com.hcl.database.UserData;

/**
 * Servlet implementation class AddItemServlet2
 */
@WebServlet("/AddItemServlet2")
public class AddItemServlet2 extends HttpServlet {
	private static final long serialVersionUID = 1L;

	final static Logger logger = Logger.getLogger(AddItemServlet2.class);

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AddItemServlet2() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		// doGet(request, response);

		UserData mbase = new UserData();
		List<OrderBean> cartList = new ArrayList<OrderBean>();
		HttpSession session = request.getSession(false);
		String emailId = (String) session.getAttribute("EmailId");
		String RestaurantName = request.getParameter("restaurantName");
		logger.info(request.getParameter("ItemCode"));
		logger.info(request.getParameter("orderAmount"));
		Float orderAmount = Float.parseFloat(request.getParameter("orderAmount"));

		logger.info("first totalamount***************" + orderAmount);

		try {
			List<MenuBean> list = mbase.getItemData(request.getParameter("restaurantName"));

			for (MenuBean mBean : list) {
				OrderBean cart = new OrderBean();
				float itemAmount = 0;
				int itemCode = Integer.parseInt(request.getParameter("ItemCode" + mBean.getItemCode()));
				int itemQuantity = Integer.parseInt(request.getParameter("quantity" + mBean.getItemCode()));
				float itemPrice = Float.parseFloat(request.getParameter("ItemPrice" + mBean.getItemPrice()));
				String itemName = request.getParameter("ItemName" + mBean.getItemName());

				if (itemQuantity > 0) {

					itemAmount = itemPrice * itemQuantity;
					orderAmount += itemAmount;

					cart.setItemCode(itemCode);
					cart.setItemName(itemName);
					cart.setItemPrice(itemPrice);
					cart.setQuantity(itemQuantity);
					cart.setItemAmount(itemAmount);

					cartList.add(cart);

				}
				logger.info("final after add********************" + orderAmount);
			}

			if (cartList.size() > 0) {

				UserData cartbase = new UserData();
				cartbase.addMenuItem(cartList, emailId);
				logger.info("final after add in another method block********************" + orderAmount);
				response.sendRedirect("Cart.jsp?restaurantName=" + RestaurantName + "&orderAmount=" + orderAmount);
			}

		} catch (SQLException e) {
			logger.error("Insert Duplicate ItemCode ======");
			response.sendRedirect("menuAddError.jsp?RestaurantName=" + request.getParameter("restaurantName")
					+ "&orderAmount=" + orderAmount);
			logger.error(e);

		}
	}
}
