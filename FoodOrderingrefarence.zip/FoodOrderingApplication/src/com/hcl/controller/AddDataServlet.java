package com.hcl.controller;

import java.io.IOException;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import org.apache.log4j.Logger;

import com.hcl.bean.OrderBean;
import com.hcl.database.UserData;

/**
 * Servlet implementation class AddDataServlet
 */
@WebServlet("/AddDataServlet")
public class AddDataServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	final static Logger logger = Logger.getLogger(AddDataServlet.class);

	/**
	 * @see HttpServlet#HttpServlet()
	 */
	public AddDataServlet() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		HttpSession session = request.getSession(false);
		String emailId = request.getParameter("EmailId");
		float orderAmount = Float.parseFloat(request.getParameter("orderAmount"));

		UserData userData = new UserData();
		try {
			boolean result = userData.insertOrder(emailId, orderAmount);
			List<OrderBean> orderList = new ArrayList<OrderBean>();
			List<OrderBean> list = userData.getMenuItem();
			logger.info("list" + list);

			for (OrderBean menuBean : list) {

				OrderBean order = new OrderBean();

				logger.info("First Name " + menuBean.getItemName());
				logger.info("ItemCode Without Parsing" + request.getParameter("ItemCode" + menuBean.getItemCode()));
				int itemCode = Integer.parseInt(request.getParameter("ItemCode" + menuBean.getItemCode()));
				int itemQuantity = Integer.parseInt(request.getParameter("quantity" + menuBean.getItemCode()));
				float itemPrice = Float.parseFloat(request.getParameter("ItemPrice" + menuBean.getItemCode()));
				String itemName = request.getParameter("ItemName" + menuBean.getItemName());
				float itemAmount = Float.parseFloat(request.getParameter("ItemAmount" + menuBean.getItemCode()));

				order.setQuantity(itemQuantity);
				order.setItemPrice(itemPrice);
				order.setItemName(itemName);
				order.setItemAmount(itemAmount);
				order.setItemCode(itemCode);
				logger.info("=================Order object values=============" + order);
				orderList.add(order);
			}
			session.setAttribute("SelectedItem", orderList);
			if (result) {
				response.sendRedirect("Order.jsp");
			} else
				logger.info("Order not placed");
		} catch (SQLException e) {
			logger.error(e);
		}
	}
}