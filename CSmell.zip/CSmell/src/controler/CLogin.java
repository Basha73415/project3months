package controler;

import java.io.IOException;

import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

@SuppressWarnings("serial")
public class CLogin extends HttpServlet {

 protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
PrintWriter pw=response.getWriter();
if(request.getParameter("username")==null || request.getParameter("username").equals(""))
{ 
pw.print("username not validate please check once agin");
}
if(request.getParameter("password")==null || request.getParameter("password").equals(""))
{ 
pw.print("password not validate please check once agin");
}

String usname,passcode;
usname=request.getParameter("usname");
passcode=request.getParameter("passcode");
try {
	Class.forName("com.mysql.jdbc.Driver");
    
    Connection con = DriverManager.getConnection
                ("jdbc:mysql:/ /localhost:3306/cfood","root","1234");
PreparedStatement ps=con.prepareStatement("select * from cusers where username=? and password=?");
ps.setString(1,usname);
ps.setString(2, passcode);
ResultSet r=ps.executeQuery();
if(r.next())
{
HttpSession se=request.getSession();
se.setAttribute("username", usname);
request.setAttribute("data", "logined in");
response.sendRedirect("CHome.html");
}
else
{
request.setAttribute("data", "data not found");
response.sendRedirect("CLogin.html");
}
} catch (Exception e) {
// TODO: handle exception
}
}

}