package controler;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.util.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Locale;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Register extends HttpServlet {

	private static final long serialVersionUID = 1L;

protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
response.setContentType("text/html");
PrintWriter p=response.getWriter();
try {
	 Class.forName("com.mysql.jdbc.Driver");
     
     Connection co = DriverManager.getConnection
                 ("jdbc:mysql:/ /localhost:3306/cfood","root","root");
String firstname,lastname,dob,email,username,password,phonenum;
long u_phone;
Date dob2=null;
firstname=request.getParameter("ftname");
lastname=request.getParameter("ltname");
dob=request.getParameter("date");
phonenum=request.getParameter("phone");
email=request.getParameter("email");
username=request.getParameter("Uname");
password=request.getParameter("pwd");
DateFormat format = new SimpleDateFormat("yyyy-mm-dd", Locale.ENGLISH);
try {
dob2 = format.parse(dob);
} catch (ParseException e1) {
p.print(e1);
}
if(firstname!=null && lastname != null && username.equals(null)&& email!=null && password!=null && dob!=null && phonenum!=null)
{
p.print("hello");
try
{
u_phone=Long.parseLong(phonenum);
}
catch(Exception e)
{
p.print("phono no is not valid");
return;
}
}
else
{
if(username.equals(null))
{
p.print("name not vaild<br>");
}
if(email==null)
{
p.print("email not valid<br>");
}

if(phonenum==null)
{
p.print("phone no not valid<br>");
}
if(dob==null)
{
p.print("dob not valid<br>");
}
}
p.println(firstname+" "+lastname+" "+username+" "+email+" "+password+" "+dob2+" "+phonenum);
java.sql.Date sqlDate = new java.sql.Date(dob2.getTime());
PreparedStatement pr=co.prepareStatement("insert into users(firstname,lastname,dob,phonenum,email,username,password) values(?,?,?,?,?,?,?)");
pr.setString(1, firstname);
pr.setString(2, lastname);
pr.setDate(3, sqlDate);
pr.setString(4, phonenum);
pr.setString(5, email);
pr.setString(6, username );
pr.setString(7, password);

 int o=pr.executeUpdate();
if(o>0)
{
p.print("registerd");
response.sendRedirect("CLogin.html");
}
else
{
p.print("not registered");
response.sendRedirect("CRegistration.html");
}
}
catch (SQLException | ClassNotFoundException ex) {
ex.printStackTrace(p);
}
}
}